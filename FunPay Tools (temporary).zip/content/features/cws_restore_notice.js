// content/features/cws_restore_notice.js
// =============================================================================
// Одноразовое уведомление: расширение временно недоступно в Chrome Web Store
// и будет восстановлено в течение 1–2 недель. Показывается ОДИН раз при заходе
// на funpay.com. Факт показа фиксируется в chrome.storage.local, чтобы модалка
// не появлялась повторно.
// =============================================================================

(function () {
    'use strict';

    const SEEN_KEY = 'fpToolsCwsRestoreNoticeSeen';
    // Версия ключа: если в будущем понадобится показать ещё раз — увеличить суффикс.
    const NOTICE_VERSION = 'v1';

    function alreadyShownSync() {
        // Быстрая защита от двойного показа в рамках одной вкладки.
        return window.__fptCwsNoticeShown === true;
    }

    async function hasBeenSeen() {
        try {
            const r = await chrome.storage.local.get(SEEN_KEY);
            return r[SEEN_KEY] === NOTICE_VERSION;
        } catch (_) {
            return false;
        }
    }

    async function markSeen() {
        try {
            await chrome.storage.local.set({ [SEEN_KEY]: NOTICE_VERSION });
        } catch (_) {}
    }

    function buildModal() {
        const overlay = document.createElement('div');
        overlay.id = 'fpt-cws-notice-overlay';
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.innerHTML = `
            <div id="fpt-cws-notice-card">
                <div id="fpt-cws-notice-icon">⚡</div>
                <h2 id="fpt-cws-notice-title">FP Tools скоро вернётся</h2>
                <p id="fpt-cws-notice-text">
                    Расширение временно недоступно в Chrome Web Store.
                    Мы уже работаем над восстановлением — ориентировочный срок
                    <b>1–2 недели</b>.
                </p>
                <p id="fpt-cws-notice-sub">
                    Все ваши функции и данные остаются на месте.
                    Спасибо, что вы с нами 💙
                </p>
                <button id="fpt-cws-notice-close" type="button">Понятно</button>
            </div>
        `;
        return overlay;
    }

    function injectStyles() {
        if (document.getElementById('fpt-cws-notice-styles')) return;
        const style = document.createElement('style');
        style.id = 'fpt-cws-notice-styles';
        style.textContent = `
            #fpt-cws-notice-overlay {
                position: fixed; inset: 0; z-index: 2147483646;
                display: flex; align-items: center; justify-content: center;
                background: rgba(10, 12, 20, 0.62);
                backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px);
                animation: fptCwsFade .22s ease-out;
            }
            @keyframes fptCwsFade { from { opacity: 0; } to { opacity: 1; } }
            @keyframes fptCwsPop {
                from { opacity: 0; transform: translateY(14px) scale(.96); }
                to   { opacity: 1; transform: translateY(0) scale(1); }
            }
            #fpt-cws-notice-card {
                width: min(92vw, 440px);
                background: linear-gradient(160deg, #1f2733 0%, #171d27 100%);
                border: 1px solid rgba(120, 150, 210, 0.22);
                border-radius: 18px;
                padding: 34px 32px 28px;
                text-align: center;
                color: #eef2f8;
                box-shadow: 0 24px 60px rgba(0,0,0,.5);
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                animation: fptCwsPop .26s cubic-bezier(.2,.8,.2,1);
            }
            #fpt-cws-notice-icon {
                font-size: 46px; line-height: 1; margin-bottom: 12px;
            }
            #fpt-cws-notice-title {
                margin: 0 0 14px; font-size: 22px; font-weight: 700;
                letter-spacing: -0.2px; color: #ffffff;
            }
            #fpt-cws-notice-text {
                margin: 0 0 12px; font-size: 15px; line-height: 1.55;
                color: #c6cede;
            }
            #fpt-cws-notice-text b { color: #ffffff; }
            #fpt-cws-notice-sub {
                margin: 0 0 24px; font-size: 13.5px; line-height: 1.5;
                color: #93a0b6;
            }
            #fpt-cws-notice-close {
                appearance: none; border: none; cursor: pointer;
                padding: 12px 30px; border-radius: 11px;
                font-size: 15px; font-weight: 600; color: #fff;
                background: linear-gradient(135deg, #4f7cff 0%, #6a5cff 100%);
                transition: transform .12s ease, box-shadow .12s ease, filter .12s ease;
                box-shadow: 0 8px 20px rgba(79, 124, 255, .35);
            }
            #fpt-cws-notice-close:hover { filter: brightness(1.07); transform: translateY(-1px); }
            #fpt-cws-notice-close:active { transform: translateY(0); }
        `;
        (document.head || document.documentElement).appendChild(style);
    }

    function closeModal(overlay) {
        if (!overlay) return;
        overlay.style.transition = 'opacity .18s ease';
        overlay.style.opacity = '0';
        setTimeout(() => overlay.remove(), 180);
    }

    async function show() {
        if (alreadyShownSync()) return;
        if (await hasBeenSeen()) return;
        window.__fptCwsNoticeShown = true;
        await markSeen(); // фиксируем сразу, чтобы гарантировать одноразовость

        injectStyles();
        const overlay = buildModal();
        document.body.appendChild(overlay);

        const closeBtn = overlay.querySelector('#fpt-cws-notice-close');
        closeBtn.addEventListener('click', () => closeModal(overlay));
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) closeModal(overlay);
        });
        document.addEventListener('keydown', function onEsc(ev) {
            if (ev.key === 'Escape') {
                closeModal(overlay);
                document.removeEventListener('keydown', onEsc);
            }
        });
    }

    function boot() {
        if (document.body) {
            show();
        } else {
            document.addEventListener('DOMContentLoaded', show, { once: true });
        }
    }

    boot();
})();
